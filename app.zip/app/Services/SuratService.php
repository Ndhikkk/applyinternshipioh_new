<?php

namespace App\Services;

use ZipArchive;

class SuratService
{
    protected string $suratPenerimaanTemplatePath;

    public function __construct()
    {
        $candidates = [
            WRITEPATH . 'templates/surat-penerimaan/Surat Penerimaan Industry-Academia Collaboration Program.docx',
            ROOTPATH . 'writable/templates/surat-penerimaan/Surat Penerimaan Industry-Academia Collaboration Program.docx',
            APPPATH . '../writable/templates/surat-penerimaan/Surat Penerimaan Industry-Academia Collaboration Program.docx',
        ];

        $this->suratPenerimaanTemplatePath = '';
        foreach ($candidates as $p) {
            if (file_exists($p)) {
                $this->suratPenerimaanTemplatePath = $p;
                break;
            }
        }

        if (!$this->suratPenerimaanTemplatePath) {
            $this->suratPenerimaanTemplatePath = WRITEPATH . 'templates/surat-penerimaan/Surat Penerimaan Industry-Academia Collaboration Program.docx';
        }
    }

    /**
     * Generate Surat Penerimaan as binary string in memory
     */
    public function generateSuratPenerimaanString(array $data): string
    {
        if (!file_exists($this->suratPenerimaanTemplatePath)) {
            throw new \RuntimeException('Template surat penerimaan tidak ditemukan di: ' . $this->suratPenerimaanTemplatePath);
        }

        $tempFile = sys_get_temp_dir() . '/surat_' . uniqid('', true) . '.docx';
        copy($this->suratPenerimaanTemplatePath, $tempFile);

        $periodeMulaiStr   = $this->formatIndonesianDate($data['periode_mulai'] ?? null, '-');
        $periodeSelesaiStr = $this->formatIndonesianDate($data['periode_selesai'] ?? null, '-');
        $tanggalTerbit     = $this->formatIndonesianDate(date('Y-m-d'), date('d F Y'));

        // Compute durasi in weeks
        $durasi = '-';
        if (!empty($data['periode_mulai']) && !empty($data['periode_selesai'])) {
            $start = strtotime($data['periode_mulai']);
            $end   = strtotime($data['periode_selesai']);
            if ($start && $end && $end > $start) {
                $weeks = (int) ceil(($end - $start) / (7 * 86400));
                $durasi = $weeks . ' minggu';
            }
        }

        $replacements = [
            '[nama_lengkap]'       => !empty($data['nama_lengkap']) ? trim($data['nama_lengkap']) : '-',
            '[nim]'                => !empty($data['nim']) ? trim($data['nim']) : '-',
            '[asal_kampus]'        => !empty($data['asal_kampus']) ? trim($data['asal_kampus']) : '-',
            '[program_studi]'      => !empty($data['program_studi']) ? trim($data['program_studi']) : '-',
            '[durasi]'             => $durasi,
            '[periode_mulai]'      => $periodeMulaiStr,
            '[periode_selesai]'    => $periodeSelesaiStr,
            '[divisi_pilihan]'     => !empty($data['divisi_pilihan']) ? trim($data['divisi_pilihan']) : '-',
            '[tanggal penerbitan]' => $tanggalTerbit,
        ];

        $zip = new ZipArchive();
        if ($zip->open($tempFile) === true) {
            $xml = $zip->getFromName('word/document.xml');
            if ($xml) {
                $xml = str_replace(array_keys($replacements), array_values($replacements), $xml);
                $zip->addFromString('word/document.xml', $xml);
            }
            $zip->close();
        }

        $binary = file_get_contents($tempFile);
        unlink($tempFile);
        return $binary;
    }

    /**
     * Format date to Indonesian (e.g. 13 April 2026)
     */
    public function formatIndonesianDate(?string $dateStr, string $fallback = ''): string
    {
        if (empty($dateStr) || $dateStr === '0000-00-00') {
            return $fallback;
        }

        $time = strtotime($dateStr);
        if (!$time) {
            return $fallback;
        }

        $months = [
            1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
            5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
            9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember',
        ];

        return date('j', $time) . ' ' . ($months[(int) date('n', $time)] ?? date('F', $time)) . ' ' . date('Y', $time);
    }
}
