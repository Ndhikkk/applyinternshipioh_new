<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;
use CodeIgniter\Filters\CSRF;
use CodeIgniter\Filters\DebugToolbar;
use CodeIgniter\Filters\Honeypot;

class Filters extends BaseConfig
{
    /**
     * Configures aliases for Filter classes to
     * make reading things nicer and simpler.
     */
    public array $aliases = [
        'csrf' => CSRF::class,
        'toolbar' => DebugToolbar::class,
        'honeypot' => Honeypot::class,
        'adminauth' => \App\Filters\AdminAuth::class,
        'throttle' => \CodeIgniter\Filters\Throttle::class,
        'autocomplete' => \App\Filters\AutoComplete::class,
    ];

    /**
     * List of filter aliases that are always
     * applied before and after every request.
     */
    public array $globals = [
        'before' => [
            // 'honeypot',
            'csrf',
        ],
        'after' => [
            'toolbar',
        ],
    ];

    /**
     * List of filter aliases that works on a
     * particular HTTP method (GET, POST, etc.).
     */
    public array $methods = [];

    /**
     * List of filter aliases that should run on any
     * before or after URI patterns.
     */

    public array $filters = [
        // AutoComplete jalan otomatis untuk semua route relevan (admin, progres, peserta)
        // Tambahkan 'pendaftaran*' jika ingin juga di form pendaftaran, atau '*' untuk global
        'autocomplete' => [
            'before' => ['admin*', 'progres*', 'peserta*'],
        ],
    ];
}
